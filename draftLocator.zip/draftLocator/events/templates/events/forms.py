from django import forms
from events.models import Events


class EventCreation(forms.ModelForm):

    class Meta:
        model = Events
        fields = ('EventName', 'Host', 'Address','Tags', 'Time', 'Date', 'Description')

        widgets = {
            'EventName': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'EventName'}),
            'Host': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Host'}),
            'Address': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Address'}),
            # 'City': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'City'}),
            # 'State': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'State'}),
            # 'Zipcode': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Zipcode'}),
            'Tags': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Tags'}),
            'Time': forms.TimeInput(attrs={'class': 'form-control', 'placeholder': 'Time'}),
            # 'Time': forms.TimeInput(attrs={'type': 'time'}),
            'Date': forms.SelectDateWidget(
                 empty_label=("Choose Year", "Choose Month", "Choose Day"),
            ),
            # forms.DateInput(attrs={'class': 'form-control', 'placeholder': 'Date'}), 
            'Description': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Description'}),
        }


