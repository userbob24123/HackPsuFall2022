from django.db import models
import django.utils


# Create your models here.

class Events(models.Model):
    EventName = models.CharField(max_length=200)
    Host = models.CharField(max_length=200, default="")
    Address = models.CharField(max_length=200)
    Tags = models.CharField(max_length=200, default="")
    Time = models.TimeField(default=django.utils.timezone.now, blank=True)
    Date = models.DateField(default=django.utils.timezone.now, blank=True)
    Description = models.TextField(max_length=500, default="")
