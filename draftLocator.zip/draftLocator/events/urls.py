from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_events, name='create-event'),
    path('', views.retrieve_events, name='view-events'),
    path('report/', views.report, name='report-event'),


]