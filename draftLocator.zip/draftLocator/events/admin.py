from django.contrib import admin
from events.models import Events

# Register your models here.

admin.site.register(Events)