from django.shortcuts import render, redirect
from events.templates.events.forms import EventCreation
from django.db import connection
from django.shortcuts import render, redirect
from django.contrib.auth import logout
from django.core.paginator import Paginator
import pyodbc
from geopy import Nominatim
from time import sleep
from django.core.mail import send_mail
import smtplib
import json


def retrieve_events(request):
    # logs out if on the map page
    if request.method == "POST":
        logout(request)
        return redirect('view-events')
    

    try:

        # establish a connection to the MSSQL server
        con = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};SERVER=ILESH-DESKTOP;PORT=1433;DATABASE=testdb;UID=sa;PWD=Password123;')
        curso = con.cursor()
        geolocator = Nominatim(user_agent="geoapiExercises")
        all_events = 1

        # getting the info from the database
        curso.execute('SELECT * FROM events_events')
        events = curso.fetchall()
        long = []
        lat = []
        names = []
    
        for i in events:
            names.append(i[1])
            loc = geolocator.geocode(i[2])
            long.append(loc.longitude)
            lat.append(loc.latitude)
            sleep(1)
        longs = json.dumps(long)
        lats = json.dumps(lat)
        print(longs, lats)
        # set up the pagination for the list of events
        p = Paginator(events, 5)
        page = request.GET.get('page')
        event_list = p.get_page(page)
        nums = 'a' * event_list.paginator.num_pages

        content = {'events': events, 'event_list': event_list, 'all': all_events, 'nums': nums, 'longs': longs, 'lats': lats, 'names': names }

        # condition used to look into the tags category
        if 'search' in request.GET:
            all_events = 0
            result_zip = request.GET['search']
        
            events = curso.fetchall()  # the data is being stored into a list. Can get by either name or event of data in the list
            p = Paginator(events, 5)
            page = request.GET.get('page')
            event_list = p.get_page(page)
            nums = 'a' * event_list.paginator.num_pages
            content = {'events': events, 'event_list': event_list, 'nums': nums,
                       'all': all_events, 'longs': longs, 'lats': lats, 'names': names}

        return render(request, 'events/view-events.html', content)
    finally:
        curso.close()


def create_events(request):
    if request.method == 'POST':
        event = EventCreation(request.POST, request.FILES)
        if event.is_valid():
            event.save()
            return redirect('view-events')
    else:
        event = EventCreation()

    return render(request, 'events/create-event.html', {'create_event': event})


def report(request):

    if request.method == "POST":
        message_name = request.POST['message-name']
        message_email = request.POST['message-email']
        message = request.POST['message']

        send_mail(

            message_name,
            message,
            message_email,
            ['iks5158@psu.edu', 'yfc5378@psu.edu', 'kmy5261@psu.edu', 'mxk6067@psu.edu', 'tml5927@psu.edu']  # the people who worked on this proj
        )
        return render(request, 'events/view-events.html')
    else:
        return render(request, 'events/report.html')

