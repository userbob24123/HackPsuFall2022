from django.shortcuts import render, redirect
from django.contrib import messages
from .templates.Users.forms import UserRegisterForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout


def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f'Your account has been created!')
            return redirect('view-events')
    else:
        form = UserRegisterForm()

    return render(request, 'Users/register.html', {'form': form})


def login_user(request):
    if request.method == 'POST':
        username = request.POST['Username']
        password = request.POST['Password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('view-events')
        else:
            messages.success(request, "There was an error with your login information. Try Again")

            return redirect('login')

    return render(request, 'Users/login.html', {})


@login_required
def profile(request):

    if request.method == "POST":
        logout(request)
        return redirect('view-events')
    else:
        return render(request, 'users/profile.html')
