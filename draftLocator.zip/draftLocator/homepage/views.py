from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.db import connection
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages

@login_required
def home(request):

    if request.method == "POST":
        logout(request)
        return redirect('view-events')
    else:

        return render(request, 'starter/Home.html')


@login_required
def about(request):

    if request.method == "POST":
        logout(request)
        return redirect('login')
    else:

        return render(request, 'starter/About.html')






