

function initMap() {
  const myLatLng = { lat: latitudes[0], lng: longitudes[0] };
  const map = new google.maps.Map(document.getElementById('map'), {
    zoom: 4,
    center: myLatLng,
    mapTypeId: google.maps.MapTypeId.ROADMAP,
    animation: google.maps.Animation.DROP,
  });
  map.setZoom(12);
  console.log(names);
  const spots = [];
  for (let i = 0; i < latitudes.length; i++){
    spots.push([{lat: latitudes[i], lng: longitudes[i]}, names[i]])
  }
  console.log(spots);
  spots.forEach(([position, title], i) => {
    new google.maps.Marker({
      position: { lat: latitudes[i], lng: longitudes[i] },
      map,
      title: `${i+1}. ${title}`,
      label: `${i + 1}`,
      optimized: false,
    });
  });
}
console.log(latitudes, longitudes);

window.initMap = initMap;
